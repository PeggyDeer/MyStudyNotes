# 一Mybatis面试总结

# 二Mybatis课程笔记

## 一）Mybatis简介

### 1什么是Mybatis

### 2Mybatis的由来

## 二）Mybatis在软件中的配置

### 1Mybatis在idea中的配置

### 2Mybatis在eclispe中的配置

## 三）Mybatis整体执行过程

四）Mybatis







1映射文件的namespace名必须是代理接口的全路径名

2接口中的方法名必须和映射文件中的id名一致

3方法入参的类型必须和parameterType一致

4方法的返回值必须和resultType一致

Mybatis接口的入参有几种形式

1原生数据类型必须带@Param注解 参数少的时候

2实体对象(User user)    多个参数

3Map集合 多个参数并且参数之间没联系

4动态sql 

<if Test="like">

where 自动去掉首个and 

foreach item 取值 得到变量的值        collection="遍历集合的类型"  

setting 里设置日志

日志 log    为了打印sql语句执行过程  方便出问题时知道哪里错了

映射器 mappers 

powerDesigner能对接所有数据库



外键应该在多的表里面 一个用户多个订单  外键应该在订单表里

订单表拽到用户表

自己表的主键用id  外键不写  其他字段用result

一对一用association

一对多用collection



PowerDesigner 笔记

关联查询要用resultMap 要和resultMap的id对应

调用对方xml就自动把实例化



级联查询 性能差 延迟加载



用到resultMap的场景

1级联查询   

2数据库表字段和java实体类的属性不一致时 手动映射

主键回填技术   只有Mybatis支持  主键  selectKey只有mysql支持  

假设user表中没有数据

插入一条记录 立马返回当前插入的id

1使用selectKey标签

select Last_INSERT_ID()







延迟加载

按需加载 提高级联查询的效率  Mybatis的延迟加载只支持级联查询



重写toString会导致触发延迟加载





org.apache.ibatis.binding.BindingException: Invalid bound statement (not found): com.oracle.mapper.UserMapper.getOrderByUserId

出现这个异常就是 xml的id和映射接口的方法名不一致  或者xml中不一致





缓存目的提高读写效率  缓存要使用在高使用率



Mybatis有自己的缓存  

一级缓存 默认开启一级缓存   sqlSession级别的仅限于同一个sqlSession   同一个sqlSession在执行相同sql语句时有缓存   并且只使用查询语句 增删改会清楚缓存  为了防止脏读

二级缓存  使用耳机缓存要使用序列化  二级缓存大于一级缓存  先看二级缓存有没有 没有去一级缓存 还没有才去数据库查   cache hit ratio 出现就是耳机缓存

只能做读取操作 而且有大小限制





出现原因可能时xml中的哪里类型匹配不对  四个一致 或者其他匹配类型

Cause: org.apache.ibatis.reflection.ReflectionException: There is no getter for property named 'com' in 'class com.oracle.entity.Card'



出现原因使用Mybatis做级联查询是xml文件中的resultMap里面重复了 

Result Maps collection already contains value for com.oracle.mapper.ClazzMapper.clazzResultMap  

![1596970674602](C:\Users\DELL\AppData\Local\Temp\1596970674602.png) 

把自己用的软件都拷贝一遍安装过程也详细点 面试时需要直接安装 有可能需要自己安装   没安装软件要回原始命令

![1596973280944](C:\Users\DELL\AppData\Local\Temp\1596973280944.png)

![1596932495227](C:\Users\DELL\AppData\Local\Temp\1596932495227.png)



java秋招，面试题

<https://blog.csdn.net/chao_ji_cai/article/details/98960419?utm_medium=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-7.channel_param&depth_1-utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-7.channel_param> 