/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2020/8/6 12:45:28                            */
/*==============================================================*/


drop table if exists `user`;

drop table if exists card;

drop table if exists item;

drop table if exists product;

drop table if exists T_order;

/*==============================================================*/
/* Table: user                                                  */
/*==============================================================*/
create table user
(
   uid                  int not null,
   uname                varchar(22),
   password             varchar(22),
   age                  int,
   sex                  varchar(22),
   primary key (uid)
);

alter table user comment '�����û���';

/*==============================================================*/
/* Table: card                                                  */
/*==============================================================*/
create table card
(
   cid                  int not null,
   uid                  int,
   code                 varchar(22),
   cname                varchar(22),
   primary key (cid)
);

/*==============================================================*/
/* Table: item                                                  */
/*==============================================================*/
create table item
(
   iid                  int not null,
   oid                  int,
   pid                  int,
   primary key (iid)
);

/*==============================================================*/
/* Table: product                                               */
/*==============================================================*/
create table product
(
   pid                  int not null,
   price                double,
   remark               varchar(22),
   pname                varchar(22),
   primary key (pid)
);

/*==============================================================*/
/* Table: ������                                                   */
/*==============================================================*/
create table ������
(
   oid                  int not null,
   uid                  int,
   oname                varchar(22),
   price                double,
   code                 varchar(22),
   primary key (oid)
);

alter table card add constraint fk_reference_1 foreign key (uid)
      references user (uid) on delete restrict on update restrict;

alter table item add constraint fk_reference_3 foreign key (oid)
      references ������ (oid) on delete restrict on update restrict;

alter table item add constraint fk_reference_4 foreign key (pid)
      references product (pid) on delete restrict on update restrict;

alter table ������ add constraint fk_reference_2 foreign key (uid)
      references `user` (uid) on delete restrict on update restrict;

