/*
Navicat MySQL Data Transfer

Source Server         : MyPeggy
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : mybatismore

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-08-09 09:10:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `stuname` varchar(22) DEFAULT NULL,
  PRIMARY KEY (`sid`),
  KEY `fk_reference_5` (`cid`),
  CONSTRAINT `fk_reference_5` FOREIGN KEY (`cid`) REFERENCES `clazz` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '1', '傻狍子');
INSERT INTO `student` VALUES ('2', '1', '袍子');
INSERT INTO `student` VALUES ('3', '1', '小老弟');
INSERT INTO `student` VALUES ('4', '1', '佩奇');
INSERT INTO `student` VALUES ('5', '1', '张三');
INSERT INTO `student` VALUES ('6', '1', '王二麻子');
INSERT INTO `student` VALUES ('7', '1', '袍跑');
INSERT INTO `student` VALUES ('8', '2', '李四');
INSERT INTO `student` VALUES ('9', '2', '唐思');
INSERT INTO `student` VALUES ('10', '2', '唐三');
INSERT INTO `student` VALUES ('11', '2', '唐舞');
INSERT INTO `student` VALUES ('12', '2', '赵六');
INSERT INTO `student` VALUES ('13', '3', '赵大');
INSERT INTO `student` VALUES ('14', '3', '潘六');
INSERT INTO `student` VALUES ('15', '3', '盘三');
INSERT INTO `student` VALUES ('16', '4', '范跑跑');
INSERT INTO `student` VALUES ('17', '4', '范老师');
