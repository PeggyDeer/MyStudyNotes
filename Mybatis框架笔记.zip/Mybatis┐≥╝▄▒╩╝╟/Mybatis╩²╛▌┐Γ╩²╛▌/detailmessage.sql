/*
Navicat MySQL Data Transfer

Source Server         : MyPeggy
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : mybatismore

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-08-09 09:11:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for detailmessage
-- ----------------------------
DROP TABLE IF EXISTS `detailmessage`;
CREATE TABLE `detailmessage` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `address` varchar(22) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(22) DEFAULT NULL,
  `scode` varchar(22) DEFAULT NULL,
  PRIMARY KEY (`did`),
  KEY `fk_reference_1` (`sid`),
  CONSTRAINT `fk_reference_1` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of detailmessage
-- ----------------------------
INSERT INTO `detailmessage` VALUES ('1', '1', '黑龙江', '23', '男', 'dfsa32rf');
INSERT INTO `detailmessage` VALUES ('2', '2', '吉林', '22', '男', 'dfsds');
INSERT INTO `detailmessage` VALUES ('3', '3', '哈尔滨', '22', '女', 'adfadsfds');
INSERT INTO `detailmessage` VALUES ('4', '4', '黑龙江', '21', '男', 'dsfadsg');
INSERT INTO `detailmessage` VALUES ('5', '5', '双城', '32', '女', 'dsfsaw');
INSERT INTO `detailmessage` VALUES ('6', '6', '阿城', '22', '女', 'adfdd');
INSERT INTO `detailmessage` VALUES ('7', '7', '双鸭山', '22', '男', 'adf');
INSERT INTO `detailmessage` VALUES ('8', '8', '黑河', '22', '女', 'adfsw');
