/*
Navicat MySQL Data Transfer

Source Server         : MyPeggy
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : mybatis2

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-08-07 17:08:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for card
-- ----------------------------
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of card
-- ----------------------------

-- ----------------------------
-- Table structure for personcard
-- ----------------------------
DROP TABLE IF EXISTS `personcard`;
CREATE TABLE `personcard` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `code` varchar(22) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `fk_reference_1` (`sid`),
  CONSTRAINT `fk_reference_1` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of personcard
-- ----------------------------
INSERT INTO `personcard` VALUES ('1', '1', 'safdw34');
INSERT INTO `personcard` VALUES ('2', '2', 'dsaga2');
INSERT INTO `personcard` VALUES ('3', '3', 'dsfassaw');
INSERT INTO `personcard` VALUES ('4', '4', 'sdfasvc3');
INSERT INTO `personcard` VALUES ('5', '5', 'sdag22');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(22) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '袍子');
INSERT INTO `student` VALUES ('2', '佩奇');
INSERT INTO `student` VALUES ('3', '哈袍子');
INSERT INTO `student` VALUES ('4', '是袍子');
INSERT INTO `student` VALUES ('5', '小老弟');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` bigint(64) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '袍子', '32423d', '34');
INSERT INTO `user` VALUES ('2', '袍子怕', '234233d', '35');
INSERT INTO `user` VALUES ('3', '傻袍子', '3244e', '34');
INSERT INTO `user` VALUES ('4', '你个傻袍', '32324e', '34');
