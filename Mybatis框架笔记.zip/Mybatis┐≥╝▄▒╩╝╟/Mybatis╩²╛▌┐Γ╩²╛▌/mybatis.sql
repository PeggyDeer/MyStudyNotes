/*
Navicat MySQL Data Transfer

Source Server         : MyPeggy
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : mybatis

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-08-07 17:08:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for card
-- ----------------------------
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `number` varchar(22) DEFAULT NULL,
  PRIMARY KEY (`cid`),
  KEY `fk_reference_1` (`uid`),
  CONSTRAINT `fk_reference_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of card
-- ----------------------------
INSERT INTO `card` VALUES ('1', '1', 'sdfsdgd');
INSERT INTO `card` VALUES ('2', '2', 'dsgsd');
INSERT INTO `card` VALUES ('3', '3', 'dsgGs');
INSERT INTO `card` VALUES ('4', '4', 'dsgadg');
INSERT INTO `card` VALUES ('5', '5', 'dsgsgagas');
INSERT INTO `card` VALUES ('6', '6', 'asfasdgsfh');

-- ----------------------------
-- Table structure for clazz
-- ----------------------------
DROP TABLE IF EXISTS `clazz`;
CREATE TABLE `clazz` (
  `cid` int(23) NOT NULL AUTO_INCREMENT,
  `cname` varchar(255) DEFAULT NULL,
  `cdate` datetime DEFAULT NULL,
  `count` int(3) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of clazz
-- ----------------------------
INSERT INTO `clazz` VALUES ('1', '01业余班', '2020-08-04 16:58:24', '50');
INSERT INTO `clazz` VALUES ('3', '02业余班', '2020-08-11 16:59:17', '34');

-- ----------------------------
-- Table structure for item
-- ----------------------------
DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `iid` int(11) NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`iid`),
  KEY `fk_reference_3` (`oid`),
  KEY `fk_reference_4` (`pid`),
  CONSTRAINT `fk_reference_3` FOREIGN KEY (`oid`) REFERENCES `tb_order` (`oid`),
  CONSTRAINT `fk_reference_4` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of item
-- ----------------------------

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `pname` varchar(22) DEFAULT NULL,
  `remark` varchar(22) DEFAULT NULL,
  `money` double DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------

-- ----------------------------
-- Table structure for tb_order
-- ----------------------------
DROP TABLE IF EXISTS `tb_order`;
CREATE TABLE `tb_order` (
  `oid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `code` varchar(22) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `createtime` date DEFAULT NULL,
  PRIMARY KEY (`oid`),
  KEY `fk_reference_2` (`uid`),
  CONSTRAINT `fk_reference_2` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_order
-- ----------------------------
INSERT INTO `tb_order` VALUES ('1', '1', 'dfsadgag', '23', '2020-08-06');
INSERT INTO `tb_order` VALUES ('2', '2', 'dsgawgd', '324', '2020-08-04');
INSERT INTO `tb_order` VALUES ('3', '1', 'dsgags', '32423', '2020-08-12');
INSERT INTO `tb_order` VALUES ('4', '2', 'dsgasgdas', '2323', '2020-08-03');
INSERT INTO `tb_order` VALUES ('5', '3', 'sdgaga', '32425', '2020-08-04');
INSERT INTO `tb_order` VALUES ('6', '1', 'sdgas', '324', '2020-08-03');
INSERT INTO `tb_order` VALUES ('7', '2', 'sdagsw', '334', '2020-08-11');
INSERT INTO `tb_order` VALUES ('8', '1', 'sdgasd', '342', '2020-08-10');
INSERT INTO `tb_order` VALUES ('9', '3', 'sdgagc', '34', '2020-08-17');
INSERT INTO `tb_order` VALUES ('10', '4', 'cvdfasv', '32424', '2020-08-17');
INSERT INTO `tb_order` VALUES ('11', '5', 'dsga', '342', '2020-08-03');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(22) DEFAULT NULL,
  `password` varchar(22) DEFAULT NULL,
  `sex` varchar(22) DEFAULT NULL,
  `age` int(22) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '袍子', '324', '女', '23');
INSERT INTO `user` VALUES ('2', '傻狍子', '3242r', '女', '34');
INSERT INTO `user` VALUES ('3', '袍子是', '324fd', '男', '34');
INSERT INTO `user` VALUES ('4', '袍子呢', 'ddsf', '男', '33');
INSERT INTO `user` VALUES ('5', '你是袍', 'adsf', '男', '23');
INSERT INTO `user` VALUES ('6', '小老弟', 'sdgs', '男', '18');
