/*
Navicat MySQL Data Transfer

Source Server         : MyPeggy
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : mybatismore

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-08-09 09:10:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for clazz
-- ----------------------------
DROP TABLE IF EXISTS `clazz`;
CREATE TABLE `clazz` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(22) DEFAULT NULL,
  `clazzcount` int(11) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of clazz
-- ----------------------------
INSERT INTO `clazz` VALUES ('1', '通信17-3班', '28');
INSERT INTO `clazz` VALUES ('2', '通信17-5班', '24');
INSERT INTO `clazz` VALUES ('3', '通信19-3班', '32');
INSERT INTO `clazz` VALUES ('4', 'Java0915班', '50');
INSERT INTO `clazz` VALUES ('5', 'Java03班', '60');
INSERT INTO `clazz` VALUES ('6', 'java04班', '30');
INSERT INTO `clazz` VALUES ('8', '物理17-3班', '30');
INSERT INTO `clazz` VALUES ('9', '化学17-3班', '30');
