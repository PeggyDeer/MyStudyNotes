/*
Navicat MySQL Data Transfer

Source Server         : MyPeggy
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : mybatismore

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-08-09 09:10:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for lesson
-- ----------------------------
DROP TABLE IF EXISTS `lesson`;
CREATE TABLE `lesson` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(22) DEFAULT NULL,
  `lscore` double DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lesson
-- ----------------------------
INSERT INTO `lesson` VALUES ('1', '数据库', '2.5');
INSERT INTO `lesson` VALUES ('2', 'java基础', '3.5');
INSERT INTO `lesson` VALUES ('3', 'html', '3.5');
INSERT INTO `lesson` VALUES ('4', 'css', '3.5');
INSERT INTO `lesson` VALUES ('5', 'js', '3.5');
INSERT INTO `lesson` VALUES ('6', 'mybatis', '5');
INSERT INTO `lesson` VALUES ('7', 'spring', '5');
INSERT INTO `lesson` VALUES ('8', 'linux', '4');
INSERT INTO `lesson` VALUES ('9', '通信原理', '3');
INSERT INTO `lesson` VALUES ('10', '信号与系统', '3');
INSERT INTO `lesson` VALUES ('11', '电磁场与电磁波', '2');
INSERT INTO `lesson` VALUES ('12', '物理基础', '2');
INSERT INTO `lesson` VALUES ('13', '物理进阶', '2');
INSERT INTO `lesson` VALUES ('14', '物理之路', '3.5');
INSERT INTO `lesson` VALUES ('15', '化学基础', '2');
INSERT INTO `lesson` VALUES ('16', '化学进阶', '2');
INSERT INTO `lesson` VALUES ('17', '化学之路', '3.5');
