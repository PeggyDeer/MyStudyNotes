/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2020/8/9 9:13:37                             */
/*==============================================================*/


drop table if exists clazz;

drop table if exists lesson;

drop table if exists student;

drop table if exists detailmessage;

drop table if exists item;

/*==============================================================*/
/* Table: clazz                                                 */
/*==============================================================*/
create table clazz
(
   cid                  int not null auto_increment,
   cname                varchar(22),
   clazzcount           int,
   primary key (cid)
);

/*==============================================================*/
/* Table: lesson                                                */
/*==============================================================*/
create table lesson
(
   lid                  int not null auto_increment,
   lname                varchar(22),
   lscore               double,
   primary key (lid)
);

/*==============================================================*/
/* Table: student                                               */
/*==============================================================*/
create table student
(
   sid                  int not null auto_increment,
   cid                  int,
   stuname              varchar(22),
   primary key (sid)
);

/*==============================================================*/
/* Table: detailmessage                                         */
/*==============================================================*/
create table detailmessage
(
   did                  int not null auto_increment,
   sid                  int,
   address              varchar(22),
   age                  int,
   sex                  int,
   scode                varchar(22),
   primary key (did)
);

/*==============================================================*/
/* Table: item                                                  */
/*==============================================================*/
create table item
(
   iid                  int not null auto_increment,
   lid                  int,
   cid                  int,
   primary key (iid)
);

alter table student add constraint fk_reference_5 foreign key (cid)
      references clazz (cid) on delete restrict on update restrict;

alter table detailmessage add constraint fk_reference_1 foreign key (sid)
      references student (sid) on delete restrict on update restrict;

alter table item add constraint fk_reference_4 foreign key (lid)
      references lesson (lid) on delete restrict on update restrict;

alter table item add constraint fk_reference_6 foreign key (cid)
      references clazz (cid) on delete restrict on update restrict;

