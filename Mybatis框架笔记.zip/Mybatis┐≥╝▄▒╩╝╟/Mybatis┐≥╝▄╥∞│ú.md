Mybatis框架部分异常

## java.lang.ClassNotFoundException:com.oracle.cj.jdbc.Driver##

存在原因

1可能是数据库没链接上 数据库的驱动 密码 用户名 路径不对

2数据库的版本不匹配 需要下载配置的驱动依赖 例如数据库是5.7的驱动不能是8的

3使用eclipse中没写配置文件 配置不对 

4在Mybatis中使用反向工程 反向工程中配置好的驱动和自己数据库中的驱动或者数据库版本不匹配 需要手动添加

![1594771133960](C:\Users\DELL\AppData\Local\Temp\1594771133960.png)

## Could not found resource com/oracle/mapper/Biz_PartsMapper.xml##

存在原因

1可能是在创建目录时 是这样的com.oracle.mapper   正常com/oracle/mapper  才是创建三层目录的包  单独看名看不出来

2可能是configuration.xml文件中没有加载这个映射文件 或者在这里写加载映射文件时把映射文件的全类名书写不一致

```.xml
下面就是configuration.xml文件中配置映射文件的内容
<mappers>
        <mapper resource="com/oracle/mapper/BizPartsMapper.xml"></mapper>
        <mapper class="com.oracle.mapper.UserMapper"></mapper>
</mappers>
```

3其他映射文件有问题 映射文件一直要有一个有问题这里就会报错找不打到

## The error occurred while processing mapper_resultMap[BaseResultMap]##

出现空指针异常 可能是动态sql查询时发现所有条件都为空 就没创建对象 如果查不到不会告诉null 会告诉空指针异常

映射文件有一个错误就会报错

创建sqlSessionFactory 会调用Mapper文件 调用加载